import { useMemo, useState, type ReactNode } from "react";
import {
  Alert,
  Button,
  Card,
  Col,
  ConfigProvider,
  Divider,
  Form,
  Input,
  Row,
  Segmented,
  Select,
  Space,
  Switch,
  Table,
  Tag,
  Typography,
  theme as antdTheme,
} from "antd";
import faIR from "antd/locale/fa_IR";
import enUS from "antd/locale/en_US";
import "antd/dist/reset.css";
import {
  PersianCalendar,
  PersianDatePicker,
  PersianDateTimePicker,
  PersianRangePicker,
  PersianTimePicker,
} from "./index";
import type { LocaleCode, NumberSystem, PickerMode, PickerValue } from "./types";
import { runCalendarTests } from "./calendar/selftest";
import { getToday } from "./calendar/calendar-utils";

const { Title, Paragraph, Text } = Typography;

const INSTALL_CMD = "npm install noora-datepicker antd";

const HOLIDAYS = [  { date: "1405/01/01", title: "نوروز" },
  { date: "1405/01/02", title: "نوروز" },
  { date: "1405/01/03", title: "نوروز" },
  { date: "1405/01/13", title: "سیزده‌به‌در" },
  { date: "1405/11/22", title: "پیروزی انقلاب" },
];

function json(v: unknown): string {
  return JSON.stringify(v, null, 2);
}

function Section(props: {
  id: string;
  title: string;
  en: string;
  children: ReactNode;
  extra?: ReactNode;
}) {
  return (
    <section id={props.id} className="demo-section">
      <div className="demo-section-head">
        <div>
          <h2>{props.title}</h2>
          <p>{props.en}</p>
        </div>
        {props.extra}
      </div>
      {props.children}
    </section>
  );
}

export default function App() {
  const [dark, setDark] = useState(false);
  const [locale, setLocale] = useState<LocaleCode>("fa");
  const [numberSystem, setNumberSystem] = useState<NumberSystem>("persian");
  const [mode, setMode] = useState<PickerMode>("date");
  const [autoConfirm, setAutoConfirm] = useState(false);
  const [playground, setPlayground] = useState<PickerValue>(null);
  const [dateVal, setDateVal] = useState<PickerValue>(null);
  const [dtVal, setDtVal] = useState<PickerValue>(null);
  const [rangeVal, setRangeVal] = useState<PickerValue>(null);
  const [multiVal, setMultiVal] = useState<PickerValue>([]);
  const [monthVal, setMonthVal] = useState<PickerValue>(null);
  const [yearVal, setYearVal] = useState<PickerValue>(null);
  const [timeVal, setTimeVal] = useState<PickerValue>(null);
  const [minmax, setMinmax] = useState<PickerValue>(null);
  const [disabledVal, setDisabledVal] = useState<PickerValue>(null);
  const [holidayVal, setHolidayVal] = useState<PickerValue>(null);
  const [presetVal, setPresetVal] = useState<PickerValue>(null);
  const [customVal, setCustomVal] = useState<PickerValue>(null);
  const [advWeek, setAdvWeek] = useState<PickerValue>(null);
  const [advTwoMonths, setAdvTwoMonths] = useState<PickerValue>(null);
  const [advMulti, setAdvMulti] = useState<PickerValue>([]);
  const [advRange, setAdvRange] = useState<PickerValue>(null);
  const [advBare, setAdvBare] = useState<PickerValue>(null);
  const [advNoPickers, setAdvNoPickers] = useState<PickerValue>(null);
  const [advCustomNames, setAdvCustomNames] = useState<PickerValue>(null);
  const [advFocus, setAdvFocus] = useState<PickerValue>(null);
  const [advFocusLog, setAdvFocusLog] = useState("—");
  const [forceMobile, setForceMobile] = useState(false);
  const [showPhonePreview, setShowPhonePreview] = useState(false);
  const [playgroundOfficial, setPlaygroundOfficial] = useState(false);
  const [monthsCount, setMonthsCount] = useState(1);
  const [officialRange, setOfficialRange] = useState<PickerValue>(null);
  const [theme, setTheme] = useState<"default" | "official">("default");
  const appearance = dark ? "dark" : theme === "official" ? "official" : "light";
  const [primary, setPrimary] = useState("#1677ff");
  const [form] = Form.useForm();

  const tests = useMemo(() => runCalendarTests(), []);
  const passed = tests.filter((t) => t.pass).length;
  const today = useMemo(() => getToday("jalali"), []);
  const dir = locale === "fa" ? "rtl" : "ltr";
  const [copied, setCopied] = useState(false);

  const copyInstall = async () => {
    try {
      await navigator.clipboard.writeText(INSTALL_CMD);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = INSTALL_CMD;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
    <ConfigProvider
      direction={dir}
      locale={locale === "fa" ? faIR : enUS}
      theme={{
        algorithm: dark ? antdTheme.darkAlgorithm : antdTheme.defaultAlgorithm,
        token: {
          fontFamily: "Vazirmatn, Tahoma, sans-serif",
          colorPrimary: primary,
          borderRadius: 10,
        },
      }}
    >
      <div className={`demo-app ${dark ? "demo-app--dark" : ""}`} dir={dir}>
        <header className="demo-nav">
          <div className="demo-brand">
            <span className="demo-logo">۱۲۳</span>
            <div>
              <strong>Noora DatePicker</strong>
              <em>Jalali · Gregorian · RTL</em>
            </div>
            <span className="demo-version">v1.0</span>
          </div>
          <div className="demo-nav-actions">
            <Segmented
              size="small"
              value={theme}
              onChange={(v) => setTheme(v as "default" | "official")}
              options={[
                { label: "پیش‌فرض", value: "default" },
                { label: "رسمی", value: "official" },
              ]}
            />
            <Segmented
              size="small"
              value={locale}
              onChange={(v) => {
                const next = v as LocaleCode;
                setLocale(next);
                setNumberSystem(next === "fa" ? "persian" : "latin");
              }}
              options={[
                { label: "فارسی", value: "fa" },
                { label: "EN", value: "en" },
              ]}
            />
            <span className="demo-switch">
              <span>تاریک</span>
              <Switch size="small" checked={dark} onChange={setDark} />
            </span>
          </div>
        </header>

        <section className="demo-hero">
          <div className="demo-hero-copy">
            <span className="demo-eyebrow">تقویم جلالی و میلادی · فارسی و انگلیسی</span>
            <h1>
              انتخابگر تاریخ شمسی
              <br />
              <span>مدرن، دقیق، آمادهٔ انتشار</span>
            </h1>
            <Paragraph className="demo-lead">
              کامپوننت React + TypeScript با موتور جلالی مستقل (کبیسه و طول ماه دقیق)،
              ۹ حالت انتخاب، دو پوسته پیش‌فرض و رسمی، شیت موبایل با چرخ روز/ماه/سال
              و خروجی ISO میلادی یا جلالی — ساخته‌شده برای فرم‌های Ant Design.
            </Paragraph>
            <div className="demo-cta">
              <Space wrap>
                <Button type="primary" size="large" href="#playground">
                  شروع زنده
                </Button>
                <Button size="large" href="#api">
                  راهنمای نصب
                </Button>
              </Space>
            </div>
            <div className="demo-install" dir="ltr">
              <code>
                <span className="dim">$ </span>npm install noora-datepicker antd
              </code>
              <button type="button" className="demo-copy" onClick={copyInstall}>
                {copied ? "کپی شد ✓" : "کپی"}
              </button>
            </div>
            <div className="demo-stats">
              <div className="demo-stat">
                <b>۹</b>
                <span>حالت انتخاب</span>
              </div>
              <div className="demo-stat">
                <b>۲</b>
                <span>تقویم و زبان</span>
              </div>
              <div className="demo-stat">
                <b>۳</b>
                <span>پوسته روشن، تیره، رسمی</span>
              </div>
              <div className="demo-stat">
                <b>{passed}/{tests.length}</b>
                <span>تست موتور تقویم</span>
              </div>
            </div>
          </div>
          <div className="demo-hero-card">
            <div className="demo-hero-label">امروز · {today.jy}/{today.jm}/{today.jd}</div>
            <PersianDatePicker
              locale={locale}
              numberSystem={numberSystem}
              appearance={appearance}
              primaryColor={primary}
              placeholder="تاریخ را انتخاب کنید"
              showToday
              allowClear
              value={dateVal}
              onChange={setDateVal}
            />
            <pre className="demo-code">{json(dateVal)}</pre>
          </div>
        </section>

        <nav className="demo-subnav" aria-label="بخش‌های مستندات">
          <div className="demo-subnav-inner">
            <a href="#playground">زمین بازی</a>
            <a href="#basic">حالت‌های انتخاب</a>
            <a href="#constraints">محدودیت‌ها</a>
            <a href="#advanced">پیشرفته</a>
            <a href="#form">فرم</a>
            <a href="#official">پوسته رسمی</a>
            <a href="#mobile">موبایل</a>
            <a href="#tests">تست‌ها</a>
            <a href="#api">نصب</a>
          </div>
        </nav>

        <Section id="playground" title="زمین بازی" en="Interactive playground">
          <Card>
            <Row gutter={[16, 16]}>
              <Col xs={24} md={8}>
                <label className="demo-label">حالت</label>
                <Select
                  style={{ width: "100%" }}
                  value={mode}
                  onChange={(v) => {
                    setMode(v);
                    setPlayground(v === "multiple" ? [] : null);
                  }}
                  options={[
                    { value: "date", label: "تاریخ" },
                    { value: "datetime", label: "تاریخ و زمان" },
                    { value: "range", label: "بازه" },
                    { value: "week", label: "هفته" },
                    { value: "multiple", label: "چندتایی" },
                    { value: "month", label: "ماه" },
                    { value: "year", label: "سال" },
                    { value: "time", label: "زمان" },
                    { value: "datetimerange", label: "بازه تاریخ‌زمان" },
                  ]}
                />
              </Col>
              <Col xs={24} md={8}>
                <label className="demo-label">اعداد</label>
                <Segmented
                  block
                  value={numberSystem}
                  onChange={(v) => setNumberSystem(v as NumberSystem)}
                  options={[
                    { label: "فارسی ۱۲۳", value: "persian" },
                    { label: "Latin 123", value: "latin" },
                  ]}
                />
              </Col>
              <Col xs={24} md={8}>
                <label className="demo-label">رنگ اصلی</label>
                <Space>
                  {["#1677ff", "#1d7d5e", "#d4380d", "#531dab"].map((c) => (
                    <button
                      key={c}
                      type="button"
                      className="demo-swatch"
                      style={{ background: c, outline: primary === c ? "2px solid #111" : undefined }}
                      onClick={() => setPrimary(c)}
                    />
                  ))}
                </Space>
              </Col>
              <Col xs={24} md={8}>
                <Space>
                  <Switch checked={autoConfirm} onChange={setAutoConfirm} />
                  <span>تأیید خودکار</span>
                </Space>
              </Col>
              <Col xs={24} md={8}>
                <Space>
                  <Switch checked={forceMobile} onChange={setForceMobile} />
                  <span>شبیه‌سازی موبایل</span>
                </Space>
              </Col>
              <Col xs={24} md={8}>
                <Space>
                  <Switch checked={playgroundOfficial} onChange={setPlaygroundOfficial} />
                  <span>پوسته رسمی</span>
                </Space>
              </Col>
              <Col xs={24} md={8}>
                <label className="demo-label">تعداد ماه</label>
                <Segmented
                  block
                  value={monthsCount}
                  onChange={(v) => setMonthsCount(v as number)}
                  options={[
                    { label: "۱", value: 1 },
                    { label: "۲", value: 2 },
                    { label: "۳", value: 3 },
                  ]}
                />
              </Col>
              <Col span={24}>
                <PersianDatePicker
                  mode={mode}
                  value={playground}
                  onChange={setPlayground}
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={playgroundOfficial ? "official" : appearance}
                  primaryColor={primary}
                  autoConfirm={autoConfirm}
                  forceVariant={forceMobile ? "mobile" : undefined}
                  numberOfMonths={monthsCount}
                  showToday
                  allowClear
                  showSecond={mode === "time" || mode === "datetime"}
                />
                <pre className="demo-code">{json(playground)}</pre>
              </Col>
            </Row>
          </Card>
        </Section>

        <Section id="basic" title="حالت‌های انتخاب" en="Selection modes">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={12}>
              <Card title="۱. تاریخ" extra={<Tag>date</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={dateVal}
                  onChange={setDateVal}
                  displayFormat="jYYYY/jMM/jDD"
                  valueFormat="YYYY-MM-DD"
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۲. تاریخ و زمان" extra={<Tag>datetime</Tag>}>
                <PersianDateTimePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={dtVal}
                  onChange={setDtVal}
                  showSecond
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۳. بازه" extra={<Tag>range</Tag>}>
                <PersianRangePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={rangeVal}
                  onChange={setRangeVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۴. چند تاریخ" extra={<Tag>multiple</Tag>}>
                <PersianDatePicker
                  mode="multiple"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={multiVal}
                  onChange={setMultiVal}
                  maxSelections={5}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۵. ماه" extra={<Tag>month</Tag>}>
                <PersianDatePicker
                  mode="month"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={monthVal}
                  onChange={setMonthVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۶. سال" extra={<Tag>year</Tag>}>
                <PersianDatePicker
                  mode="year"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={yearVal}
                  onChange={setYearVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۷. زمان" extra={<Tag>time</Tag>}>
                <PersianTimePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={timeVal}
                  onChange={setTimeVal}
                  showSecond
                  minuteStep={5}
                />
              </Card>
            </Col>
          </Row>
        </Section>

        <Section id="constraints" title="محدودیت‌ها و تعطیلات" en="Min / max, disabled, holidays">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={8}>
              <Card title="۸. حداقل / حداکثر">
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  minDate="1405/01/01"
                  maxDate="1405/12/29"
                  value={minmax}
                  onChange={setMinmax}
                  placeholder="فقط سال ۱۴۰۵"
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۹. جمعه‌ها غیرفعال">
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={disabledVal}
                  onChange={setDisabledVal}
                  disabledDate={(d) => d.weekday === 6}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۱۰. تعطیلات">
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  holidays={HOLIDAYS}
                  value={holidayVal}
                  onChange={setHolidayVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۱۱. میانبرها" extra={<Tag>presets</Tag>}>
                <PersianDatePicker
                  mode="range"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  showPresets
                  value={presetVal}
                  onChange={setPresetVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۱۲. رندر سفارشی روز">
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={customVal}
                  onChange={setCustomVal}
                  holidays={HOLIDAYS}
                  renderDay={(date, node) => (
                    <span style={{ display: "flex", flexDirection: "column", alignItems: "center", lineHeight: 1 }}>
                      {node}
                      {date.isHoliday ? (
                        <small style={{ fontSize: 8, color: "#ff4d4f" }}>تعطیل</small>
                      ) : null}
                    </span>
                  )}
                />
              </Card>
            </Col>
          </Row>
        </Section>

        <Section id="advanced" title="قابلیت‌های پیشرفته" en="Week, multi-month, separators & more">
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={8}>
              <Card title="۱۶. انتخاب هفته" extra={<Tag>week</Tag>}>
                <PersianDatePicker
                  mode="week"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={advWeek}
                  onChange={setAdvWeek}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۱۷. دو ماه کنار هم" extra={<Tag>numberOfMonths</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  numberOfMonths={2}
                  value={advTwoMonths}
                  onChange={setAdvTwoMonths}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۱۸. چندتایی مرتب" extra={<Tag>sortDates</Tag>}>
                <PersianDatePicker
                  mode="multiple"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  sortDates
                  multipleSeparator=" | "
                  maxSelections={5}
                  value={advMulti}
                  onChange={setAdvMulti}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۱۹. بازه با جداکننده" extra={<Tag>rangeSeparator</Tag>}>
                <PersianDatePicker
                  mode="range"
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  rangeSeparator="الی"
                  value={advRange}
                  onChange={setAdvRange}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۲۰. گرید خلوت" extra={<Tag>hideWeekdays</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  hideWeekdays
                  showOtherDays={false}
                  highlightToday={false}
                  value={advBare}
                  onChange={setAdvBare}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="۲۱. بدون انتخاب‌گر ماه/سال" extra={<Tag>disableMonthPicker</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  disableMonthPicker
                  disableYearPicker
                  value={advNoPickers}
                  onChange={setAdvNoPickers}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۲۲. نام‌های سفارشی" extra={<Tag>monthNames</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  monthNames={["فر", "ار", "خر", "تیر", "مر", "شه", "مهر", "آبا", "آذر", "دی", "بهم", "اسف"]}
                  weekdayNames={["ش", "ی", "د", "س", "چ", "پ", "ج"]}
                  value={advCustomNames}
                  onChange={setAdvCustomNames}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۲۳. رویداد فوکس" extra={<Tag>onFocusedDateChange</Tag>}>
                <PersianDatePicker
                  locale={locale}
                  numberSystem={numberSystem}
                  appearance={appearance}
                  value={advFocus}
                  onChange={setAdvFocus}
                  onFocusedDateChange={(d) =>
                    setAdvFocusLog(d ? `${d.jy}/${d.jm}/${d.jd}` : "—")
                  }
                />
                <pre className="demo-code" dir="ltr">{advFocusLog}</pre>
              </Card>
            </Col>
          </Row>
        </Section>

        <Section id="form" title="ادغام با Ant Design Form" en="Form integration">
          <Card>
            <Form
              form={form}
              layout="vertical"
              onFinish={(vals) => {
                window.alert(json(vals));
              }}
            >
              <Row gutter={16}>
                <Col xs={24} md={8}>
                  <Form.Item name="name" label="نام" rules={[{ required: true, message: "الزامی" }]}>
                    <Input placeholder="مثلاً مریم" />
                  </Form.Item>
                </Col>
                <Col xs={24} md={8}>
                  <Form.Item
                    name="birthDate"
                    label="تاریخ تولد"
                    rules={[{ required: true, message: "تاریخ تولد را وارد کنید" }]}
                  >
                    <PersianDatePicker
                      locale={locale}
                      numberSystem={numberSystem}
                      appearance={appearance}
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} md={8}>
                  <Form.Item name="period" label="بازه مرخصی">
                    <PersianRangePicker
                      locale={locale}
                      numberSystem={numberSystem}
                      appearance={appearance}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Button type="primary" htmlType="submit">
                ارسال فرم
              </Button>
            </Form>
          </Card>
        </Section>

        <Section id="inline" title="تقویم درون‌خطی" en="Inline calendar">
          <Card>
            <PersianCalendar
              locale={locale}
              numberSystem={numberSystem}
              appearance={appearance}
              primaryColor={primary}
              showToday
            />
          </Card>
        </Section>

        <Section
          id="official"
          title="پوسته رسمی"
          en="Official theme"
          extra={<Tag color="green">appearance=&quot;official&quot;</Tag>}
        >
          <Paragraph>
            پوسته رسمی فروشگاه (دکمه سفید، سربرگ سبز با سوییچ فا/EN، نوار خاکستری
            ماه با نام روز هفته زیر هر روز، انتخاب با بوردر سبز). همه امکانات پوسته
            پیش‌فرض (بنر، فوتر کامل، میانبرها، بازه، چندتایی) این‌جا هم فعال است؛ فقط
            دکمه‌های پرش سال ندارد. برای اعمال فوری با کلیک گزینه{" "}
            <Text code>autoConfirm</Text> را هم بگذارید. نام قبلی{" "}
            <Text code>golsetan</Text> همچنان به‌عنوان نام مستعار کار می‌کند.
          </Paragraph>
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={12}>
              <Card title="۱۳. فیلد یادآور">
                <PersianDatePicker
                  locale="fa"
                  numberSystem="persian"
                  appearance="official"
                  placeholder="تاریخ یادآوری"
                  autoConfirm
                  value={dateVal}
                  onChange={setDateVal}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۱۴. تقویم درون‌خطی رسمی">
                <PersianCalendar
                  locale="fa"
                  numberSystem="persian"
                  appearance="official"
                  showToday
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="۱۵. بازه رسمی" extra={<Tag>range</Tag>}>
                <PersianDatePicker
                  mode="range"
                  locale="fa"
                  numberSystem="persian"
                  appearance="official"
                  showPresets
                  value={officialRange}
                  onChange={setOfficialRange}
                />
              </Card>
            </Col>
          </Row>
        </Section>

        <Section
          id="mobile"
          title="پیش‌نمایش موبایل"
          en="Mobile bottom sheet"
          extra={
            <Space>
              <span>نمایش شبیه‌ساز</span>
              <Switch checked={showPhonePreview} onChange={setShowPhonePreview} />
            </Space>
          }
        >
          <Paragraph>
            در عرض کمتر از ۷۶۸ پیکسل، پیکر به‌صورت شیت پایین با چرخ روز / ماه / سال باز می‌شود.
            می‌توانید «شبیه‌سازی موبایل» را در زمین بازی روشن کنید، یا با پراپ{" "}
            <Text code>forceVariant=&quot;mobile&quot;</Text> در هر کدی شیت موبایل را به‌دلخواه
            نمایش دهید.
          </Paragraph>
          {showPhonePreview ? (
            <div className="demo-phone">
              <div className="demo-phone-bar" />
              <div className="demo-phone-body">
                <p className="demo-phone-title">رزرو نوبت</p>
                <PersianDatePicker
                  locale="fa"
                  numberSystem="persian"
                  appearance={appearance}
                  forceVariant="mobile"
                  placeholder="انتخاب تاریخ مراجعه"
                  autoConfirm={false}
                />
                <PersianDatePicker
                  mode="datetime"
                  locale="fa"
                  numberSystem="persian"
                  appearance={appearance}
                  forceVariant="mobile"
                  placeholder="تاریخ و ساعت"
                />
              </div>
            </div>
          ) : null}
        </Section>

        <Section
          id="tests"
          title="تست موتور جلالی"
          en="Calendar engine self-tests"
          extra={
            <Tag color={passed === tests.length ? "success" : "error"}>
              {passed}/{tests.length} passed
            </Tag>
          }
        >
          <Alert
            type={passed === tests.length ? "success" : "error"}
            showIcon
            message={
              passed === tests.length
                ? "تمام آزمون‌های تبدیل، سال کبیسه، طول ماه و اعتبارسنجی عبور کردند."
                : "برخی آزمون‌ها شکست خوردند."
            }
            style={{ marginBottom: 16 }}
          />
          <Table
            size="small"
            pagination={false}
            rowKey="name"
            dataSource={tests}
            columns={[
              {
                title: "آزمون",
                dataIndex: "name",
              },
              {
                title: "وضعیت",
                dataIndex: "pass",
                width: 120,
                render: (pass: boolean) =>
                  pass ? <Tag color="success">PASS</Tag> : <Tag color="error">FAIL</Tag>,
              },
              {
                title: "جزئیات",
                dataIndex: "detail",
                render: (d: string) => <Text code>{d}</Text>,
              },
            ]}
          />
        </Section>

        <Section id="api" title="نصب و استفاده" en="Install & usage">
          <Card>
            <Title level={5}>Installation</Title>
            <pre className="demo-code">{INSTALL_CMD}</pre>
            <Title level={5}>Basic usage</Title>
            <pre className="demo-code">{`import { PersianDatePicker } from "noora-datepicker";
import "noora-datepicker/styles.css";

<PersianDatePicker
  locale="fa"
  calendar="jalali"
  mode="date"
  displayFormat="jYYYY/jMM/jDD"
  valueFormat="YYYY-MM-DD"
  numberSystem="persian"
  placeholder="انتخاب تاریخ"
  allowClear
  showToday
  autoConfirm={false}
  value={value}
  onChange={setValue}
/>`}</pre>
            <Title level={5}>Official theme</Title>
            <pre className="demo-code">{`<PersianDatePicker appearance="official" autoConfirm />`}</pre>
            <Divider />
            <Text type="secondary">
              مقدار پیش‌فرض خروجی، تاریخ میلادی ISO است (مثلاً 2026-10-11) در حالی که نمایش
              شمسی باقی می‌ماند. برای خروجی جلالی، valueFormat=&quot;jYYYY/jMM/jDD&quot; بگذارید.
            </Text>
          </Card>
        </Section>

        <footer className="demo-foot">
          <div className="demo-foot-inner">
            <div>
              <h4>Noora DatePicker</h4>
              <p>
                انتخابگر تاریخ و زمان جلالی برای React + TypeScript + Ant Design.
                موتور تقویم مستقل از UI · RTL بومی · SSR-safe.
              </p>
            </div>
            <div>
              <h4>بخش‌ها</h4>
              <a href="#playground">زمین بازی</a>
              <a href="#basic">حالت‌های انتخاب</a>
              <a href="#advanced">قابلیت‌های پیشرفته</a>
              <a href="#official">پوسته رسمی</a>
            </div>
            <div>
              <h4>نصب</h4>
              <p dir="ltr" style={{ textAlign: "left" }}>{INSTALL_CMD}</p>
              <a href="#api">راهنمای استفاده</a>
              <a href="#tests">تست موتور تقویم</a>
            </div>
          </div>
          <div className="demo-foot-base">
            Jalali engine · TypeScript · Ant Design 5 · v1.0
          </div>
        </footer>
      </div>
    </ConfigProvider>
  );
}
